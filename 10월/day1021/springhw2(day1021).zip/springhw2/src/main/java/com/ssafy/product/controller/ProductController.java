package com.ssafy.product.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;


@Controller
//@RequestMapping("/product")
public class ProductController {   
	
	@Autowired
	private ProductService service;
	
	
	@RequestMapping("/form")
	public String form() {
		System.out.println(">>>>>>");
      return "form";
    }
	
	@RequestMapping("/regist")
	public String regist(Product product, Model model ) {
	  try {
		service.regist(product);  
	  } catch (SQLException e) {
		e.printStackTrace();
	  }
      return "redirect:/list";
    }	
	
	@RequestMapping("/list")
	public String list(Model model ) {
		try {
			model.addAttribute("list",service.findAll() );
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "list";
	}		
	
  
}
