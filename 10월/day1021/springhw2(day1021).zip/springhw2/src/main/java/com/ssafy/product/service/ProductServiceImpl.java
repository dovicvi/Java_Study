package com.ssafy.product.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dao.ProductDAO;
import com.ssafy.product.dto.Product;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
	private ProductDAO dao;
	
	@Override
	public void regist(Product product) throws SQLException {
		dao.insert(product);
	}

	@Override
	public void modify(Product product) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(String id) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public Product find(String id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findAll() throws SQLException {		
		return dao.selectAll();
	}

}
