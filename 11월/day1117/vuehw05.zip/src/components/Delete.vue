<template>
    <div>
        삭제중입니다.
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name: 'Delete',

    created() {
    const params = new URL(document.location).searchParams;
    axios.delete(`http://localhost:8080/ssafy/api/${params.get('id')}`).then(({ data }) => {
      let msg = '삭제 처리시 문제가 발생했습니다.';
      if (data.state === 'succ') {
        msg = '삭제가 완료되었습니다.';
      }
      alert(msg);
      this.$router.push('/hrmlist');
    });
    }
}
</script>

<style>

</style>