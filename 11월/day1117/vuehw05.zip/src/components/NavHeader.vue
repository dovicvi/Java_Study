<template>
    <p>
      <router-link to="/">HOME</router-link>
      <router-link to="/hrmlist">목록</router-link>
    </p>
</template>

<script>
    export default{
        name: 'NavHeader'
    }
</script>

<style>
</style>