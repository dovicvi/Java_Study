import Vue from "vue";
import VueRouter from "vue-router";

import List from '@/components/List.vue';
import Create from '@/components/Create.vue';
import Detail from '@/components/Detail.vue';
import Delete from '@/components/Delete.vue';

// import Home from "../views/Home.vue";

Vue.use(VueRouter);

export default new VueRouter({
  mode: 'history',
  routes: [
    {
      path: '/hrmlist',
      name: 'hrmlist',
      component: List,
    },
    {
      path: '/hrmcreate',
      name: 'hrmcreate',
      component: Create,
    },
    {
      path: '/hrmdetail',
      name: 'hrmdetail',
      component: Detail,
    },
    {
      path: '/hrmdelete',
      name: 'hrmdelete',
      component: Delete,
    }   
  ],
});
